# @babel/plugin-proposal-async-generator-functions

> Turn async generator functions into ES2015 generators

See our website [@babel/plugin-proposal-async-generator-functions](https://babeljs.io/docs/en/babel-plugin-proposal-async-generator-functions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-async-generator-functions
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-async-generator-functions --dev
```
